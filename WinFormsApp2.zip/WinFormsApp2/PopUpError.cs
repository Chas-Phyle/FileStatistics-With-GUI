﻿namespace WinFormsApp2
{
    public partial class PopUpError : Form
    {
        public PopUpError()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
